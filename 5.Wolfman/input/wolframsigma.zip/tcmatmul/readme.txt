made you click!😏


testcase format:

"""
<n size of square matrix>
<nxn elements of first square matrix>

<nxn elements of second square matrix>

"""